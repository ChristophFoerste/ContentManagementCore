<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<div class="page-header">
    <h3><?php echo $this->lang->line("adminList_head_mainPage"); ?></span></h3>
</div>

<div class="row">
    <div class="col-xs-12" id="adminTablePlaceholder">
        <?php echo $adminTable; ?>
    </div>
</div>