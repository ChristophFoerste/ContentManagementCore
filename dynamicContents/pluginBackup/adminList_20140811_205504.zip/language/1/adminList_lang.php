<?php
//header
$lang['adminList_head_mainPage']                    = "Liste der Administratoren";

//error messages
$lang['adminList_error_noListElements']             = "Keine Administratoren verfügbar";

//table translator
$lang['adminList_tableTranslator_ID']               = "ID";
$lang['adminList_tableTranslator_admin_username']   = "Nutzername";
$lang['adminList_tableTranslator_admin_realName']   = "Name";
$lang['adminList_tableTranslator_admin_lastActive'] = "letzter Login";
$lang['adminList_tableTranslator_admin_userAgent']  = "zuletzt verwendeter Browser";
?>