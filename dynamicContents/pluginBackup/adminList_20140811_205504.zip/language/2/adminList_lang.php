<?php
//header
$lang['adminList_head_mainPage']             = "List of Administrators";


//error messages
$lang['adminList_error_noListElements']      = "No administrators available";

//table translator
$lang['adminList_tableTranslator_ID']               = "ID";
$lang['adminList_tableTranslator_admin_username']   = "username";
$lang['adminList_tableTranslator_admin_realName']   = "name";
$lang['adminList_tableTranslator_admin_lastActive'] = "last login";
$lang['adminList_tableTranslator_admin_userAgent']  = "last browser type";
?>